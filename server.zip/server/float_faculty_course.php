<?php


	// This is used to float a new course by faculty.


	session_start();
	// user_id can be accessed using $_SESSION['user_id'];

	$course_id = $_POST['course_id'];

	
	$data = new stdClass();
	$data->err = "OK";

	echo json_encode($data);
?>